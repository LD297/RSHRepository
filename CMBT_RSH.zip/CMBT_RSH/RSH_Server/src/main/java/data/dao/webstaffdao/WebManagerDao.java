package data.dao.webstaffdao;

/**
 * Created by aa on 2016/11/22.
 */
public interface WebManagerDao {
}
