package data.dao.webstaffdao;

import java.rmi.Remote;

/**
 * Created by aa on 2016/11/22.
 */
public interface WebSalesmanDao extends Remote{

}
