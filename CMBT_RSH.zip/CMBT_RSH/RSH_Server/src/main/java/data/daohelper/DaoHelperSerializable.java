package data.daohelper;

/**
 * Created by a297 on 16/11/27.
 */
public class DaoHelperSerializable {
}
