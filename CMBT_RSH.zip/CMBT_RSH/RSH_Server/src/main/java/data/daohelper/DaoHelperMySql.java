package data.daohelper;

/**
 * Created by a297 on 16/11/27.
 */
public abstract class DaoHelperMySql {
    public abstract void init();
    public abstract void finish();
}
