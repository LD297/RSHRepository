package data.daohelperimpl.hoteldaohelperimpl;

import data.daohelper.DaoHelperTextFile;

/**
 * Created by a297 on 16/11/27.
 */
public class HotelDaoHelperTextFile extends DaoHelperTextFile{
}
