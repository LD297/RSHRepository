package data.daohelperimpl.hoteldaohelperimpl;

import data.daohelper.DaoHelperSerializable;

/**
 * Created by a297 on 16/11/27.
 */
public class HotelDaoHelperSerializable extends DaoHelperSerializable {
}
