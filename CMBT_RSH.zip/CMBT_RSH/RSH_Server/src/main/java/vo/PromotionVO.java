package vo;

public class PromotionVO {

}
