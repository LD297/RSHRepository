package constant;

public enum ResultMessage {
	succeed,
	fail,
	emptyComment
}
