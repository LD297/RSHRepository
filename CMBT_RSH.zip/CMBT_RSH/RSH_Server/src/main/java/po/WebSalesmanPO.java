package po;

public class WebSalesmanPO {

	String id;
	String password;
	String district;
}
