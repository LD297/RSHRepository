package po;

public class PromotionPO {

	String setter;
	String reason;
	String scope;
	String  conditionType;
    String promotionType;
}
