package po;

public class HotelStaffPO {

	String hotelID;
	String tel;
	
	public HotelStaffPO(String hotelID, String tel) {
		super();
		this.hotelID = hotelID;
		this.tel = tel;
	}
	
}
