package po;

public class WebManagerPO {

	String id;
	String password;
}
