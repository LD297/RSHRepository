package po;

public class WebManagerPO {

	String id;
	String password;

	public String getPassword(){
		return password;
	}
}
