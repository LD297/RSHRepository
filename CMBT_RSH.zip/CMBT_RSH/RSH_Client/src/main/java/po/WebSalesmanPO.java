package po;

public class WebSalesmanPO {

	String id;
	String password;
	String district;

	public String getID(){
		return id;
	}

	public String getPassword(){
		return password;
	}

	public String getDistrict(){
		return district;
	}
}
