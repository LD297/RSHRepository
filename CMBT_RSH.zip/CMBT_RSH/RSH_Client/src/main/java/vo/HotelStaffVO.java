package vo;

/**
 * Created by a297 on 16/11/20.
 */
public class HotelStaffVO {
    public String hotelID;
    public String tel;

    public HotelStaffVO(String hotelID, String tel) {
        this.hotelID = hotelID;
        this.tel = tel;
    }
}
