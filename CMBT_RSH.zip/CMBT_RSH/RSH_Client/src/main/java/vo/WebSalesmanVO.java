package vo;

public class WebSalesmanVO {

}
