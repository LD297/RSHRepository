package bl.promotionServiceimpl;

/**
 * 优惠的条件种类
 * @author aa
 *
 */
public class ConditionType {

	int num;
	
	/**
	 * 检测是否符合条件
	 * @param condition
	 * @return
	 */
	public boolean check(int condition){
		boolean result=false;
		
		return false;
	}
}
