package bl.promotionServiceimpl;

/**
 * 折扣优惠
 * @author aa
 *
 */
public class DiscountDeduction extends Deduction {

	int discount;
	
	public DiscountDeduction(int disc){
		discount=disc;
	}
	
	public int getPromotion(int total){
		int result=total;
		
		return result;
	}
}
