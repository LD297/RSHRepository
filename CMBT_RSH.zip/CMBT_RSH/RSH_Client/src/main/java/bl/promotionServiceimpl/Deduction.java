package bl.promotionServiceimpl;

/**
 * 优惠的种类
 * @author aa
 *
 */
public class Deduction {

	public int getPromotion(int total){
		
		return total;
	}
}
