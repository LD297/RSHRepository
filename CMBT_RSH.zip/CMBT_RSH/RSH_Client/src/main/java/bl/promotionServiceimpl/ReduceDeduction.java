package bl.promotionServiceimpl;

/**
 * 减额优惠
 * @author aa
 *
 */
public class ReduceDeduction extends Deduction {

	public int getPromotion(int total){
		
		return total;
	}
	
}
