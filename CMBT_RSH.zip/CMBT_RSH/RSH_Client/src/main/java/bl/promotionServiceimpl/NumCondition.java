package bl.promotionServiceimpl;

/**
 * 对数量的要求
 * @author aa
 *
 */
public class NumCondition extends ConditionType{

	int num;
	
	public NumCondition(int n){
		num=n;
	}
	
	public boolean check(int num){
		boolean result=false;
		
		return result;
	}
}
