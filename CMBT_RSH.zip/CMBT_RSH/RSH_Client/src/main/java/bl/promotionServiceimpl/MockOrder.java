package bl.promotionServiceimpl;

import bl.orderserviceimpl.Order;

public class MockOrder extends Order{

}
