package presentation.dto;

/**
 * Created by a297 on 16/11/26.
 */
public class UserDto {
}
