package presentation.view;

/**
 * Created by a297 on 16/11/26.
 */
public class UserView {
}
