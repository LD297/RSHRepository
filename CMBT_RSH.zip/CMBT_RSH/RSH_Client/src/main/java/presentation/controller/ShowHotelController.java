package presentation.controller;

import constant.HotelOrderStateOfUser;

public class ShowHotelController {

//	调用orderservice返回该用户在该酒店的订单状态
//	public HotelOrderStateOfUser getOrderStateOfUser(String id, String userID);
}
