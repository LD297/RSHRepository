package constant;

public enum condition {

	Date,
	IsBirthday,
	IsEnterprise,
	RoomNumber,
	Consumption
}
