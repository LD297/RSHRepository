package constant;

public enum SortMethod {
	ascend,dscend
}
