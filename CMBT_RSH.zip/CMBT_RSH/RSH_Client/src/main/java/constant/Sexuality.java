package constant;

public enum Sexuality {
	male,
	female
}
