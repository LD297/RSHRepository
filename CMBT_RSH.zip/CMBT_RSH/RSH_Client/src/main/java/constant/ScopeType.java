package constant;

public enum ScopeType {

}
