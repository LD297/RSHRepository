package constant;

public enum CreditAction {
	bymoney,cancel,abnormal,execute,delay_checkin,cancel_abnomal
}
