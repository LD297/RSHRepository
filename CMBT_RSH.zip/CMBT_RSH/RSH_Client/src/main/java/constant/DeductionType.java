package constant;

public enum DeductionType {

}
