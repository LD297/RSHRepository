package constant;

public enum Role {
user,hotel,webmanager,websalesman
}
