package constant;

public enum MemberType {
	commom,
	commerce
}
