package presentation.view;

import static org.junit.Assert.*;

/**
 * Created by a297 on 16/11/27.
 */
public class HotelInfoViewTest {


}